// T�lkis: M�rt Tibar, http://mardu.nohik.net

Calendar.LANG("et", "Eesti keel", {

        fdow: 1,                // first day of week for this locale; 0 = Sunday, 1 = Monday, etc.

        goToday: "Liigu t�nasele",

        today: "T�na",         // appears in bottom bar

        wk: "ndl",

        weekend: "0,6",         // 0 = Sunday, 1 = Monday, etc.

        AM: "EL",

        PM: "PL",

        mn : [ "jaanuar",
               "veebruar",
               "m�rts",
               "aprill",
               "mai",
               "juuni",
               "juuli",
               "august",
               "september",
               "oktoober",
               "november",
               "detsember" ],

        smn : [ "jaan",
                "veebr",
                "m�rts",
                "apr",
                "mai",
                "juuni",
                "juuli",
                "aug",
                "sept",
                "okt",
                "nov",
                "dets" ],

        dn : [ "p�hap�ev",
               "esmasp�ev",
               "teisip�ev",
               "kolmap�ev",
               "neljap�ev",
               "reede",
               "laup�ev",
               "p�hap�ev" ],

        sdn : [ "P",
                "E",
                "T",
                "K",
                "N",
                "R",
                "L",
                "P" ]

});
